function y = rnd(x)
    y = double(x>rand());
end